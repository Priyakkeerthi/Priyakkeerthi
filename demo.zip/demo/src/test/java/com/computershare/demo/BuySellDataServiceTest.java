package com.computershare.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuySellDataServiceTest {

	@Autowired
	private BuySellDataService buySellDataService;

	// Test for positive case
	@Test
	void findBuySellDataTest() {
		String testFileName = "classpath:ChallengeSampleDataSet2.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, "16(15.61),14(27.2)");
	}

	
	/*
	 * Test for case when data in file is minimum or maximum than the number of days
	 * in a month
	 */
	 
	@Test
	void findBuySellDataInconsistentDaysTest() {
		String testFileName = "classpath:ChallengeSampleTestDataSet1.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, GlobalConstants.DAYS_COUNT_MISMATCH_ERR);
	}

	// Test for case when file is not in path
	@Test
	void findBuySellDataFileNotFoundTest() {
		String testFileName = "classpath:ChallengeSampleTestDataSet_1.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, GlobalConstants.FILE_NOT_FOUND_ERR);
	}

	// Test case for file having no content
	@Test
	void findBuySellDataEmptyFileTest() {
		String testFileName = "classpath:ChallengeSampleTestEmptyDataSet1.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, GlobalConstants.EMPTY_FILE_CONTENT_ERR);
	}

	// Test case for file having more than one line
	@Test
	void findBuySellDataMoreLinesTest() {
		String testFileName = "classpath:ChallengeSampleTestMoreLinesTestDataSet.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, GlobalConstants.MORE_THAN_A_LINE_ERR);
	}

	// Test case for file having invalid character
	@Test
	void findBuySellDataInvalidCharTest() {
		String testFileName = "classpath:ChallengeSampleTestInvalidDataSet.txt";
		String result = buySellDataService.findBuySellData(testFileName);
		assertEquals(result, GlobalConstants.INVALID_CHARACTER_ERR);
	}
}
