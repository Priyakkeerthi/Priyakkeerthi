package com.computershare.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComputershareCodingChallengeApplicationTests {
	
	@InjectMocks
	private BuySellDataController controller;
	
	@Mock
	private BuySellDataService buySellDataService;
	
	@Test
	void contextLoads() {
		assertNotNull(controller);
	}
	
	@Test
	public void getBuySellDataTest() throws Exception {
		String testFileName = "classpath:ChallengeSampleDataSet2.txt";
		String mockedResult = "16(10.61),14(20.05)";
		when(buySellDataService.findBuySellData(testFileName)).thenReturn(mockedResult);
		
		String result = controller.getBuySellData();
		assertEquals(result, mockedResult);
	}

}
