package com.computershare.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BuySellDataController {
	
	@Autowired
	private BuySellDataService buySellDataService;
	
	@GetMapping("/getBuySellData")
	public String getBuySellData() {
		String fileName = "classpath:ChallengeSampleDataSet1.txt";
		return buySellDataService.findBuySellData(fileName);		
	}
}
