package com.computershare.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

/**
 * Service class that supplies the buy day and sell day of month with respective stock prices
 * 
 */

@Service
public class BuySellDataService {

	private static final Logger logger = LoggerFactory.getLogger(BuySellDataService.class);
	
	/**
	 * @param {fileName}
	 * @returns string in format -> buyDayOfMonth(price),sellDayOfMonth(price)
	 */
	public String findBuySellData(String filePath) {
		String result = null;
		try {
			File file = ResourceUtils.getFile(filePath);
			Scanner myReader;
			myReader = new Scanner(file);
			
			int counter = 0;
			while (myReader.hasNextLine()) {
				counter++;
				if(counter > 1) {
					myReader.close();
					return GlobalConstants.MORE_THAN_A_LINE_ERR;
				}
				String data = myReader.nextLine();
				result = validateData(data);		
				String[] stockPrices = data.split(",");
				if(result == null)
					result = findLowHighValues(stockPrices);
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			result = GlobalConstants.FILE_NOT_FOUND_ERR;
			logger.error(e.getMessage());
		}
		return result == null ? GlobalConstants.EMPTY_FILE_CONTENT_ERR : result;
	}

	/**
	 * Method that contains logic to find buy and sell day with price
	 * @param array of stockPrice 
	 * @returns string in format -> buyDayOfMonth(price),sellDayOfMonth(price)
	 */
	private String findLowHighValues(String[] stockPrices) {
		int buyDayOfMonth = 0;
		int sellDayOfMonth = 0;
		double minPrice = Double.parseDouble(stockPrices[buyDayOfMonth]);
		double	maxPrice = Double.parseDouble(stockPrices[sellDayOfMonth]);

		for (int i = 1; i < stockPrices.length; i++) {
			double stockPrice = Double.parseDouble(stockPrices[i]);
			if (stockPrice < minPrice) {
				minPrice = stockPrice;
				buyDayOfMonth = i;
			} else if (stockPrice > maxPrice) {
				maxPrice = stockPrice;
				sellDayOfMonth = i;
			}
		}
		buyDayOfMonth = buyDayOfMonth + 1;
		sellDayOfMonth = sellDayOfMonth + 1;
		String buyDay = buyDayOfMonth + GlobalConstants.SIMPLE_BRACKET_OPEN + String.valueOf(minPrice)
				+ GlobalConstants.SIMPLE_BRACKET_CLOSE;
		String sellDay = sellDayOfMonth + GlobalConstants.SIMPLE_BRACKET_OPEN + String.valueOf(maxPrice)
				+ GlobalConstants.SIMPLE_BRACKET_CLOSE;
		return buyDay + GlobalConstants.COMMA_SEPARATER + sellDay;
	}
	
	/**
	 * @param line from input file as string
	 * @return string will error message, null if no error
	 * 
	 * Method that validates input string for cases
	 * 1. Empty String
	 * 2. Invalid Character
	 * 3. stock price for day count is invalid
	 * */
	private String validateData(String data) {
		String result = null;
		if (data == null) {
			result = GlobalConstants.EMPTY_FILE_CONTENT_ERR;
		}
		String[] stockPrices = data.split(",");
		String regex = "^\\d*\\.?\\d+$";
		Pattern pattern = Pattern.compile(regex);
		for (String price : stockPrices) {
			Matcher matcher = pattern.matcher(price);
			if (!matcher.matches()) {
				result = GlobalConstants.INVALID_CHARACTER_ERR;
			}
		}		
		if (stockPrices.length < GlobalConstants.MIN_DAYS_IN_MNTH
				|| stockPrices.length > GlobalConstants.MAX_DAYS_IN_MNTH) {
			result = GlobalConstants.DAYS_COUNT_MISMATCH_ERR;
		}
		return result;
	}

}
