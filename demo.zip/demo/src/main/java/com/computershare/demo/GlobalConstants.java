package com.computershare.demo;

/*Simple class that contains all the constant values used in the project*/

public class GlobalConstants {
	private GlobalConstants() {
	}
	public final static int MIN_DAYS_IN_MNTH = 28;
	public final static int MAX_DAYS_IN_MNTH = 31;
	public final static String SIMPLE_BRACKET_OPEN = "(";
	public final static String SIMPLE_BRACKET_CLOSE = ")";
	public final static String COMMA_SEPARATER = ",";	
	public final static String FILE_NOT_FOUND_ERR = "Input file not available in path";
	public final static String DAYS_COUNT_MISMATCH_ERR = "Input should contain atleast 28 or atmost 31 entries";
	public final static String EMPTY_FILE_CONTENT_ERR = "Input file is empty";
	public final static String MORE_THAN_A_LINE_ERR = "Input file cannot have more than a line";
	public final static String INVALID_CHARACTER_ERR = "Input data can contain only comma separated decimels";
}
